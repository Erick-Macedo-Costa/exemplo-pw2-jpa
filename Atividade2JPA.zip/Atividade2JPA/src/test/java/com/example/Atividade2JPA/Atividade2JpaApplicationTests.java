package com.example.Atividade2JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade2JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
