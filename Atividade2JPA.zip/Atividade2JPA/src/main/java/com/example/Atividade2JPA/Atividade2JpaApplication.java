package com.example.Atividade2JPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade2JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Atividade2JpaApplication.class, args);
	}

}
