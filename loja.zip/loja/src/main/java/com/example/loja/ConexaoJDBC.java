package com.example.loja;

import java.sql.Connection;

public interface ConexaoJDBC {

    public Connection criarConexao();

}
